/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author USER
 */
public class PreOrder {
    // Properties dengan access modifier private
    private int id;
    private String namaPelanggan;
    private String jenisKain;
    private int jumlah;

    // Constructor
    public PreOrder(int id, String namaPelanggan, String jenisKain, int jumlah) {
        this.id = id;
        this.namaPelanggan = namaPelanggan;
        this.jenisKain = jenisKain;
        this.jumlah = jumlah;
    }

    // Getter & Setter
    public int getId() {
        return id;
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
    }

    public String getJenisKain() {
        return jenisKain;
    }

    public void setJenisKain(String jenisKain) {
        this.jenisKain = jenisKain;
    }

    public int getJumlah() {
        return jumlah;
    }

    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }

    @Override
    public String toString() {
        return "ID: " + id +
               " | Nama: " + namaPelanggan +
               " | Jenis Kain: " + jenisKain +
               " | Jumlah: " + jumlah;
    }
}
