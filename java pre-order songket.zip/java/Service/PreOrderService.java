/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;
import java.util.ArrayList;
import java.util.Scanner;
import Model.PreOrder;
/**
 *
 * @author USER
 */
public class PreOrderService {
    private ArrayList<PreOrder> listPreOrder = new ArrayList<>();
    private int nextId = 1;
    private Scanner scanner = new Scanner(System.in);

    // CREATE
    public void tambahPreOrder() {
        System.out.print("Masukkan nama pelanggan: ");
        String nama = scanner.nextLine();

        if (nama.trim().isEmpty()) {
            System.out.println("Nama tidak boleh kosong!");
            return;
        }

        System.out.print("Masukkan jenis kain songket: ");
        String jenis = scanner.nextLine();

        if (jenis.trim().isEmpty()) {
            System.out.println("Jenis kain tidak boleh kosong!");
            return;
        }

        System.out.print("Masukkan jumlah: ");
        try {
            int jumlah = Integer.parseInt(scanner.nextLine());
            if (jumlah <= 0) {
                System.out.println("Jumlah harus lebih dari 0!");
                return;
            }

            PreOrder po = new PreOrder(nextId++, nama, jenis, jumlah);
            listPreOrder.add(po);
            System.out.println("Pre-order berhasil ditambahkan!");
        } catch (NumberFormatException e) {
            System.out.println("Jumlah harus berupa angka!");
        }
    }

    // READ
    public void tampilkanPreOrder() {
        if (listPreOrder.isEmpty()) {
            System.out.println("Belum ada data pre-order.");
            return;
        }
        for (PreOrder po : listPreOrder) {
            System.out.println(po);
        }
    }

    // UPDATE
    public void updatePreOrder() {
        System.out.print("Masukkan ID pre-order yang akan diupdate: ");
        int id = Integer.parseInt(scanner.nextLine());

        PreOrder po = cariById(id);
        if (po == null) {
            System.out.println("Data tidak ditemukan!");
            return;
        }

        System.out.print("Masukkan nama baru (kosongkan jika tidak diubah): ");
        String nama = scanner.nextLine();
        if (!nama.trim().isEmpty()) po.setNamaPelanggan(nama);

        System.out.print("Masukkan jenis kain baru (kosongkan jika tidak diubah): ");
        String jenis = scanner.nextLine();
        if (!jenis.trim().isEmpty()) po.setJenisKain(jenis);

        System.out.print("Masukkan jumlah baru (0 = tidak diubah): ");
        try {
            int jumlah = Integer.parseInt(scanner.nextLine());
            if (jumlah > 0) po.setJumlah(jumlah);
        } catch (NumberFormatException e) {
            System.out.println("Jumlah tidak valid, data lama tetap digunakan.");
        }

        System.out.println("Data berhasil diperbarui!");
    }

    // DELETE
    public void hapusPreOrder() {
        System.out.print("Masukkan ID pre-order yang akan dihapus: ");
        int id = Integer.parseInt(scanner.nextLine());

        PreOrder po = cariById(id);
        if (po == null) {
            System.out.println("Data tidak ditemukan!");
            return;
        }
        listPreOrder.remove(po);
        System.out.println("Data berhasil dihapus!");
    }

    // SEARCH
    public void cariPreOrder() {
        System.out.print("Masukkan nama pelanggan yang dicari: ");
        String keyword = scanner.nextLine().toLowerCase();

        boolean ditemukan = false;
        for (PreOrder po : listPreOrder) {
            if (po.getNamaPelanggan().toLowerCase().contains(keyword)) {
                System.out.println(po);
                ditemukan = true;
            }
        }
        if (!ditemukan) {
            System.out.println("Tidak ada data dengan nama tersebut.");
        }
    }

    // Helper untuk cari by ID
    private PreOrder cariById(int id) {
        for (PreOrder po : listPreOrder) {
            if (po.getId() == id) {
                return po;
            }
        }
        return null;
    }
}
